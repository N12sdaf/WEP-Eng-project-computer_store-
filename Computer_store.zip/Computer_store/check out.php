<?php
session_start();

if (!isset($_SESSION['UserID'])) {
    header( 'Location: logout.php' );
    exit;
}

include 'DB_connection.php';


if(isset($_POST['cardname'], $_POST['cardnumber'], $_POST['expmonth'], $_POST['expyear'], $_POST['cvv'])){
   $_SESSION['card']= $_POST['cardnumber'];
   if(isset($_SESSION['UserID'])){
  $carddate= $_POST['expyear'].'/'. $_POST['expmonth'];


  
  $query = $conn->prepare("INSERT INTO `payment`(`CardNumber`, `Name`, `date`, `CVV`, `UserID`) VALUES (?,?,?,?,?)");
  $query->bind_param('sssis', $_POST['cardnumber'],$_POST['cardname'], $carddate, $_POST['cvv'],$_SESSION['UserID']);
  $query->execute();
  $query->close();

header('Location:order.php');

}else{
  echo '<div id="container" ><div class="alert alert-danger" role="alert">
 You are not logged    </div></div><br>';
}


$conn->close();

}
?>

<html>

<head>
<link rel="stylesheet" href="./bootstrab/bootstrap.min.css">

<link rel="stylesheet" href="ch.css">
    <meta charset="utf-8">
<style>
  .backbutt{
	position:fixed;
	bottom: 20px;
	right: 30px;
	z-index: 99;
	border: none;
	outline: none;
	background-color: #0c0c0d;
	color: white;
	cursor: pointer;
	padding: 15px;
	border-radius: 10px;
	bottom: 90%;
right: 90%;
}  
.backbutt:hover {
	background-color: #555;
  }
</style>
</head>
  <body>
    <button class="backbutt" onclick="tocart()">back</button>
    <div class="row">
      <div class="col-75">
        <div class="container">
          <form method="POST">
    
            <div class="row">
              <div class="col-50">
                <h3>Payment</h3>
             

                <label for="cname">Name on Card</label>
                <input type="text" id="cname" name="cardname" placeholder="John More Doe">
                <label for="ccnum">Credit card number</label>
                <input type="text" id="ccnum" name="cardnumber" placeholder="1111-2222-3333-4444">
                <label for="expmonth">Exp Month</label>
                <input type="text" id="expmonth" name="expmonth" placeholder="September">
  
                <div class="row">
                  <div class="col-50">
                    <label for="expyear">Exp Year</label>
                    <input type="text" id="expyear" name="expyear" placeholder="2018">
                  </div>
                  <div class="col-50">
                    <label for="cvv">CVV</label>
                    <input type="text" id="cvv" name="cvv" placeholder="352">
                  </div>
                </div>
              </div>
              
            </div>
        
            <button class="btn btn-primary" style="width:50%;background-color:rgb(45, 45, 201);" type="submit" >Pay</button>

          </form>
        </div>
      </div>
    </div>
 <script>
  function tocart(){
    window.location.href="index.php";
  }
 </script>
</body>

</html>