<?php
include 'DB_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

if (isset($_POST['UserName'], $_POST['UserID'], $_POST['password'])) {
    //$userpassword=hash('sha512',$_POST['password']);

      $query = $conn->prepare("CALL `signup`(?,?,?)");
      $query->bind_param('sss', $_POST['UserID'] ,$_POST['UserName'], $_POST['password']);
      $query->execute();
      if($conn->error){
        echo '<div id="container"><div class="alert alert-danger" role="alert">
        Failed to signup,try again later     </div></div><br>';
      }else{
        echo '<div class="alert alert-success" role="alert">
        Your account has created successfuly
      </div>';
      }
      $query->close();
    }
      //$_SESSION['name']
    
}



?>