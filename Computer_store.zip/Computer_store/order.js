let subtotal = 0;
var products =[];
console.log(products);
const allproducts = {
    'MSI GeForce RTX 3090 24GB GDDR6X': 1499,
    'GIGABYTE GeForce RTX 3060 12GB GDDR6': 329,
    'MSI GeForce RTX 3070 8GB GDDR6': 499,
    'MSI GeForce RTX 3080ti 12GB GDDR6X': 699,
    'MSI GeForce RTX 4090 24GB GDDR6X': 1199,
    'MSI GeForce RTX 4080 16GB GDDR6X': 899,
    'GIGABYTE GeForce RTX 4060 WINDFORCE OC 8GB GDDR6': 559,
    'Intel Core i9-14900K - Core i9 14th Gen 24-Core': 559,
    'Intel Core i5-12600KF - Core i5 12th Gen Alder Lake 10-Core': 199
};

function addProductToCart() {
    for (const tocart in allproducts) {
        const add_to_cart = document.getElementById(tocart);
        add_to_cart.addEventListener('click', function () {
            products.push({ name: tocart, price: allproducts[tocart], quantity: 1 });
            localStorage.setItem("cart", JSON.stringify(products));
        });
    }
}
addProductToCart();