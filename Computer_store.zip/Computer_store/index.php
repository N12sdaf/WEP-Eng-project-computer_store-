
<?php
session_start();

if (!isset($_SESSION['UserID'])) {
    header( 'Location: logout.php' );
    exit;
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8" name="viewport" width="device-width">
<title>	Shopping cart</title>
</head>
<link rel="stylesheet" href="style.css">
<body>
	
	<div class="background">
		<div class="wrapper">
			<button onclick="backtomain()" class="backbutt">back</button>
			<h1>Shopping Cart</h1>
				<div class="project">
					<div class="shop" id="cart-container">
						<div class="box">
							<div class="content">
								<h3>product name</h3>
								<h4>price:$10.00</h4>
								<p class="btn-area">
								<i class="trash"></i>
								<span class="btn2">Remove</span>
								</p>
							</div>
						</div>
						<div class="box">
							<div class="content">
								<h3>product name</h3>
								<h4>price:$10.00</h4>
								<p class="btn-area">
								<i class="trash"></i>
								<span class="btn2">Remove</span>
								</p>
							</div>
						</div>
						<div class="box">
							<div class="content">
								<h3>product name</h3>
								<h4>price:$10.00</h4>
								<p class="btn-area">
								<i class="trash"></i>
								<span class="btn2">Remove</span>
								</p>
							</div>
						</div>
					</div>

				<div class="right-bar">
					<p><span>Subtotal</span><span id="subtotal"></span></p>
					<p><span>Shipping</span><span>$15.00</span></p>
					<hr>
					<p><span>Total</span><span id="total"></span></p>
					<a href="check out.php" onclick="check()"><i class="shopping-cart"></i>Checkout</a>
					<a id="clearcart" ><i class="shopping-cart"></i>clear cart</a>
				</div>

			</div>
		</div>
	</div>
        <script src="cart.js"></script>
    
</body>
</html>