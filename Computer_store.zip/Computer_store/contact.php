<?php
session_start();

if (!isset($_SESSION['UserID'])) {
    header( 'Location: login.php' );
    exit;
}

include 'phpmailer.php';
if(isset($_POST["UEmail"],$_POST["Umassage"])){
   $umassage= $_POST["Umassage"];
   $uemail= $_POST["UEmail"];
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'selftriage22@gmail.com';
        $mail->Password = 'icrziehnektjrejl';
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        $mail->setFrom('selftriage22@gmail.com',$uemail); 
        $mail->addAddress('nawaf.dh.alharbi@gmail.com');

        $mail->Subject = 'Custmer feedback';
        $mail->Body =$umassage;

        if ($mail->send()) {
            
            exit;
        } else {
            $error = '<div class="container">
            <div class="alert alert-danger d-flex align-items-center" role="alert">
          <svg class="bi flex-shrink-0 me-2" width="24" height="24" role="img" aria-label="Danger:"><use xlink:href="#exclamation-triangle-fill"/></svg>
          <div>
          Failed to send OTP, Please try again</div>
        </div>
          </div></div>';
        }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="./bootstrab/bootstrap.min.css">
<link rel="stylesheet" href="contact.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact with owner</title>
</head>
<body>
    <button onclick="backtomain()">Back</button>
    <div class="container">
<h1>Contact with store owners!</h1>
<form method="POST">
    <div class="mb-3">
  <label for="exampleFormControlInput1" class="form-label">Your Email</label>
  <input type="email" class="form-control" id="exampleFormControlInput1" name="UEmail" placeholder="name@example.com">
</div>
<div class="mb-3">
  <label for="exampleFormControlTextarea1" class="form-label">Your massage</label>
  <textarea class="form-control" id="exampleFormControlTextarea1" name="Umassage" rows="3"></textarea>
</div>
<input type="submit" value="Send" class="btn btn-primary" style="width:15%;background-color:rgb(45, 45, 201);">
</form>
<h1 style="color:white">Store owners</h1>
<div class="cards">
<div class="card text-white bg-dark mb-3" style="max-width: 18rem;     margin-right: 30px;">
  <div class="card-header">Contact Info</div>
  <div class="card-body">
    <h5 class="card-title">Nawaf Alharbi</h5>
    <p class="card-text"><i style="font-size:24px" class="fa">&#xf0e0;</i> tu4001781@taibahu.edu.sa <br>
    <i style="font-size:24px" class="fa">&#xf095;</i>  1010122234
</p>
  </div>
</div>
<div class="card text-white bg-dark mb-3" style="max-width: 18rem; margin-right: 30px;">
  <div class="card-header">Contact Info</div>
  <div class="card-body">
    <h5 class="card-title">Osama Al- Mohammadi</h5>
    <p class="card-text"><i style="font-size:24px" class="fa">&#xf0e0;</i> tu4201044@taibahu.edu.sa <br>
    <i style="font-size:24px" class="fa">&#xf095;</i>  12000333332
</p>
  </div>
</div>
<div class="card text-white bg-dark mb-3" style="max-width: 18rem; margin-right: 30px;">
  <div class="card-header">Contact Info</div>
  <div class="card-body">
    <h5 class="card-title">Ahmed Turkistani</h5>
    <p class="card-text"><i style="font-size:24px" class="fa">&#xf0e0;</i> tu3901786@taibahu.edu.sa <br>
    <i style="font-size:24px" class="fa">&#xf095;</i>  14492902089
</p>
  </div>
</div>
<div class="card text-white bg-dark mb-3" style="max-width: 18rem; margin-right: 30px;">
  <div class="card-header">Contact Info</div>
  <div class="card-body">
    <h5 class="card-title">Abdullah Al-Harbi </h5>
    <p class="card-text"><i style="font-size:24px" class="fa">&#xf0e0;</i> tu4002658@taibahu.edu.sa <br>
    <i style="font-size:24px" class="fa">&#xf095;</i>  12000212342
</p>
  </div>
</div>






</div>
    </div>

    <script>
        function backtomain(){
    window.location.href="main.php";
}
    </script>
</body>
</html>