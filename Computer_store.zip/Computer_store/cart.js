var products = JSON.parse(localStorage.getItem("cart")) || [];
const cartContainer = document.getElementById('cart-container');
var clearcart=document.getElementById("clearcart");

//var arr =[{dead:"yes",alive:"no"}];
clearcart.addEventListener("click",()=>{
   localStorage.clear();
   products =[];   
    updateCart();

});


function removeItem(name){
    products = products.filter(p => p.name != name);
    localStorage.setItem("cart", JSON.stringify(products));
    updateCart();
}

function updateCart() {
    cartContainer.innerHTML = ""; // Clear the cart before updating
    subtotal = 0;

    products.forEach(product => {
        const itemDiv = document.createElement('div');
        itemDiv.classList.add('box');

        itemDiv.innerHTML = `
            <div class="content">
                <h3>${product.name}</h3>
                <h4>Price: $${product.price.toFixed(2)}</h4>
                <p class="btn-area">
                    <i class="trash"></i>
                    <span class="btn2" onclick="removeItem('${product.name}')">Remove</span>
                </p>
            </div>
        `;

        cartContainer.appendChild(itemDiv);
        //subtotal += product.price;
    });

    updateTotal();
}

function updateTotal() {
    var subtotalspan=document.getElementById("subtotal");
    var totalspan=document.getElementById("total");
    products.forEach(product=>{
        subtotal+=product.price;
    }  )
   var total=subtotal+15;
    localStorage.setItem("total",JSON.stringify(total));
    subtotalspan.innerHTML="$"+subtotal;
    totalspan.innerHTML="$"+total;
}
function backtomain(){
    window.location.href="main.php";
}

//
updateCart();

