function confOrder(){
    window.location.href="order.php"
}
var totalp = JSON.parse(localStorage.getItem("total"));
var products = JSON.parse(localStorage.getItem("cart")) || [];
const d_cart =Object.assign({},products);
        const data = {
            cartproducts: JSON.stringify(d_cart),
            totalprice: JSON.stringify(totalp)
        };
        fetch('order.php', {
            method: 'POST',
            body: JSON.stringify(data),
            headers: {
                'Content-Type': 'application/json; charset=utf-8'
            }
        })
        .then(function(response){
            return response.text();
        }).then(function(data) {
           
            console.log(data);
           
        })
        .catch(error => {
            console.error('Error:', error);
        });

    var elements=document.getElementById("productsCON");
for(const toview in d_cart){
    const itemDiv = document.createElement('div');
    itemDiv.innerHTML=`<h4 style="color:#8bc34a;">-${JSON.stringify(d_cart[toview].name)}</h4>`
    elements.appendChild(itemDiv);

}

function Startnew(){
    localStorage.clear();
}