<?php
include 'DB_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

if (isset($_POST['UserName'], $_POST['UserID'], $_POST['password'])) {
    //$userpassword=hash('sha512',$_POST['password']);

      $query = $conn->prepare("CALL `signup`(?,?,?)");
      $query->bind_param('sss', $_POST['UserID'] ,$_POST['UserName'], $_POST['password']);
      $query->execute();
      if($conn->error){
        echo "failed to sign up";
      }else{
        echo "you signed up secssfuly";
      }
      $query->close();
    }
      //$_SESSION['name']
    
}



?>