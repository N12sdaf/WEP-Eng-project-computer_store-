
<?php

session_start();

include 'DB_connection.php';
include 'register.php';
include 'account.php';

$conn->close();

?>



<!DOCTYPE html>
<html>
<head>
	<title>Slide Navbar</title>
	    <link rel="stylesheet" href="./bootstrab/bootstrap.min.css">

	<link rel="stylesheet" type="text/css" href="login.css">
<link href="https://fonts.googleapis.com/css2?family=Jost:wght@500&display=swap" rel="stylesheet">
</head>
<body>
	<div class="main">  	
		<input type="checkbox" id="chk" aria-hidden="true">

			<div class="signup">
				<form action="login.php" method="POST">
					<label for="chk" aria-hidden="true">Sign up</label>
					<input type="text" name="UserName" placeholder="your name" required="">
					<input type="text" name="UserID" placeholder="your ID" required="">
					<input type="password" name="password" placeholder="Password" required="">
					<button type="submit">Sign up</button>
				</form>
			</div>

			<div class="login">
				
				<form method="POST">
					<label for="chk" aria-hidden="true">Login</label>
					<input type="text" name="login_UserID" placeholder="your ID">
					<input type="password" name="login_password" placeholder="Password">
					<button type="submit">Login</button>
				</form>
			</div>
	</div>

</body>
</html>


