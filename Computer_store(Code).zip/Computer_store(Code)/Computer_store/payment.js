function confOrder(){
    window.location.href="order.php"
}