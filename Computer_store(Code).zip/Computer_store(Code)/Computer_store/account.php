<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
if (isset($_POST['login_UserID'], $_POST['login_password'])) {

    $userpassword=hash('sha512',$_POST['login_password']);
    $userID=$_POST['login_UserID'];
      $query = $conn->prepare("SELECT * FROM custmer WHERE UserID=?");
      $query->bind_param('s', $userID);
      $query->execute();
      $query->bind_result($db_ID, $db_name,$db_password);
      $query->fetch();
      if ($userpassword == $db_password){
        $_SESSION['username']=$db_name;
        $_SESSION['UserID']=$db_ID;
        $_SESSION['userpassword']=$db_password;

        header("Location: main.php");

      }else{
        echo '<div id="container"><div class="alert alert-danger" role="alert">
incorrect userID or password      </div></div><br>';
    }

      $query->close();

    }
}
?>