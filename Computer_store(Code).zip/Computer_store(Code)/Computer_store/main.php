<?php
session_start();

if (!isset($_SESSION['UserID'])) {
    header( 'Location: login.php' );
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Shopping Website</title>
    <link rel="stylesheet" type="text/css" href="main.css">
      

</head>

<body>
    <div class="sidebar">
        <h2>Categories</h2>
        <ul>
            <li><a href="#GPUs">GPUs & Video Graphics Devices</a></li>
            <li><a href="#CPUs">CPUs / Processors</a></li>
        </ul>
    </div>
    <div class="main-content">
        <nav>
            <a href="index.php">Cart <span class="cart-icon">🛒</span></a>
        </nav>
        <header>
            <h1>Welcome <?php echo $_SESSION['username'];?> to our computer store Website!</h1>
        </header>
        <main>
            <div id="GPUs" class="product-box">
                <h2>- GPUs & Video Graphics Devices</h2>
                <div class="product-grid">
                    <div class="product-card">
                        <img src="images/MSIRTX3090.jpg" alt="MSI RTX 3090">
                        <h2 class="product-name">MSI GeForce RTX 3090 24GB GDDR6X</h2>
                        <p class="product-price">$1499</p>
                        <button id="MSI GeForce RTX 3090 24GB GDDR6X">Add to Cart</button>
                    </div>
                    <div class="product-card">
                        <img src="images/RTX3060.jpg" alt="RTX 3060">
                        <h2 class="product-name">GIGABYTE GeForce RTX 3060 12GB GDDR6</h2>
                        <p class="product-price">$329</p>
                        <button id="GIGABYTE GeForce RTX 3060 12GB GDDR6">Add to Cart</button>
                    </div>
                    <div class="product-card">
                        <img src="images/RTX3070.jpg" alt="RTX 3070">
                        <h2 class="product-name">MSI GeForce RTX 3070 8GB GDDR6</h2>
                        <p class="product-price">$499</p>
                        <button id='MSI GeForce RTX 3070 8GB GDDR6'>Add to Cart</button>
                    </div>
                    <div class="product-card">
                        <img src="images/RTX3080.jpg" alt="RTX 3080">
                        <h2 class="product-name">MSI GeForce RTX 3080ti 12GB GDDR6X</h2>
                        <p class="product-price">$699</p>
                        <button id="MSI GeForce RTX 3080ti 12GB GDDR6X">Add to Cart</button>
                    </div>
                    <div class="product-card">
                        <img src="images/RTX4090.jpg" alt="RTX 4090">
                        <h2 class="product-name">MSI GeForce RTX 4090 24GB GDDR6X</h2>
                        <p class="product-price">$1199</p>
                        <button id="MSI GeForce RTX 4090 24GB GDDR6X">Add to Cart</button>
                    </div>
                    <div class="product-card">
                        <img src="images/RTX4080.jpg" alt="RTX 4080">
                        <h2 class="product-name">MSI GeForce RTX 4080 16GB GDDR6X</h2>
                        <p class="product-price">$899</p>
                        <button id="MSI GeForce RTX 4080 16GB GDDR6X">Add to Cart</button>
                    </div>
                    <div class="product-card">
                        <img src="images/RTX4060.jpg" alt="RTX 4060">
                        <h2 class="product-name">GIGABYTE GeForce RTX 4060 WINDFORCE OC 8GB GDDR6</h2>
                        <p class="product-price">$559</p>
                        <button id="GIGABYTE GeForce RTX 4060 WINDFORCE OC 8GB GDDR6">Add to Cart</button>
                    </div>
                    <!-- Add more GPU -->
                </div>
            </div>
            <div id="CPUs" class="product-box">
                <h2>- CPUs & Processors</h2>
                <div class="product-grid">
                    <div class="product-card">
                        <img src="images/Intel_i9.jpg" alt="Intel Core i9">
                        <h2 class="product-name">Intel Core i9-14900K - Core i9 14th Gen 24-Core</h2>
                        <p class="product-price">$599</p>
                        <button id="Intel Core i9-14900K - Core i9 14th Gen 24-Core">Add to Cart</button>
                    </div>
                    <div class="product-card">
                        <img src="images/Intel_i5.jpg" alt="Intel Core i5">
                        <h2 class="product-name">Intel Core i5-12600KF - Core i5 12th Gen Alder Lake 10-Core</h2>
                        <p class="product-price">$199</p>
                        <button id="Intel Core i5-12600KF - Core i5 12th Gen Alder Lake 10-Core">Add to Cart</button>
                    </div>
                    <!-- Add more CPU -->
                </div>
            </div>
        </main>
    </div>
    <script src="order.js"></script>
</body>

</html>