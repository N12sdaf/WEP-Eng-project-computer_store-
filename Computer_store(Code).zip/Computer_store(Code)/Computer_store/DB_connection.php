<?php

$servername = "127.0.0.1";
    $username = "root";
    $dbPassword = "";
    $dbname = "computerstore";

    $conn = new mysqli($servername, $username, $dbPassword, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    ?>